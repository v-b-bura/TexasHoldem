/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package holdem;

import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 *
 * @author ValentinBura
 */
public class BetPanel extends JPanel{
    
    
    final PokerInterface p;
    
    JTextArea lbl = new JTextArea("Pot");
    JButton onePot = new JButton("+1");
    JButton fivePot = new JButton("+5");
    JButton tenPot = new JButton("+10");
    JButton fiftyPot = new JButton("+50");
    JButton hundredPot = new JButton("+100");
    
    public JTextArea pot = new JTextArea();
    
    
    JTextArea lbl_ = new JTextArea("Bet");
    JButton oneBet = new JButton("+1");
    JButton fiveBet = new JButton("+5");
    JButton tenBet = new JButton("+10");
    JButton fiftyBet = new JButton("+50");
    JButton hundredBet = new JButton("+100");
    
    public JTextArea bet = new JTextArea();
    
    BetPanel(PokerInterface pokerInterface){
    
        Font font = pot.getFont();
        float size = 50;
        pot.setFont( font.deriveFont(size) );
        bet.setFont( font.deriveFont(size) );
        pot.setEditable(false);
        bet.setEditable(false);
        pot.setBackground(UIConstants.TABLE_COLOR);
        bet.setBackground(UIConstants.TABLE_COLOR);
        
        lbl.setFont( font.deriveFont(size) );
        lbl_.setFont( font.deriveFont(size) );
        lbl.setBackground(UIConstants.TABLE_COLOR);
        lbl_.setBackground(UIConstants.TABLE_COLOR);
        
        this.p = pokerInterface;
        
        this.setBackground(UIConstants.TABLE_COLOR);
    
        this.setLayout(new GridLayout(2,7));
    
        this.add(lbl);
        this.add(onePot);
        this.add(fivePot);
        this.add(tenPot);
        this.add(fiftyPot);
        this.add(hundredPot);
        this.add(pot);

        this.add(lbl_);
        this.add(oneBet);
        this.add(fiveBet);
        this.add(tenBet);
        this.add(fiftyBet);
        this.add(hundredBet);
        this.add(bet);
              
        
        onePot.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            
                p.pot+=1;
                pot.setText(p.pot+"");
            }});
        fivePot.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            
                p.pot+=5;
                pot.setText(p.pot+"");
               
            }});
        tenPot.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            
                p.pot+=10;
                pot.setText(p.pot+"");
               
            }});
        fiftyPot.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            
                p.pot+=50;
                pot.setText(p.pot+"");
               
            }});
        hundredPot.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            
                p.pot+=100;
                pot.setText(p.pot+"");
               
            }});
        oneBet.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            
                p.bet+=1;
                bet.setText(p.bet+"");
               
            }});
        fiveBet.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            
                p.bet+=5;
                bet.setText(p.bet+"");
               
            }});
        tenBet.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            
                p.bet+=10;
                bet.setText(p.bet+"");
               
            }});
        fiftyBet.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            
                p.bet+=50;
                bet.setText(p.bet+"");
               
            }});
        hundredBet.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            
                p.bet+=100;
                bet.setText(p.bet+"");
               
            }});
    }
    
    
}
