/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package holdem;

import java.util.Scanner;

/**
 *
 * @author ValentinBura
 */
class HoldemRanking {

    /**
     * @param args the command line arguments
     */
    public static void ranking() {
        /*  public final static int SPADES = 0;    
            public final static int HEARTS = 1;
            public final static int DIAMONDS = 2;
            public final static int CLUBS = 3;*/
        
        
        //PokerInterface pokerInterface = new PokerInterface();
        
        
        Scanner scan = new Scanner(System.in);
        int num = Integer.parseInt(scan.nextLine());
        int suit = Integer.parseInt(scan.nextLine());
        int num_ = Integer.parseInt(scan.nextLine());
        int suit_ = Integer.parseInt(scan.nextLine());
        
        //pre flop
        PokerCard c1 = new PokerCard(num,suit);
        PokerCard c2 = new PokerCard(num_,suit_);
        rank(c1,c2);
        
        int num__ = Integer.parseInt(scan.nextLine());
        int suit__ = Integer.parseInt(scan.nextLine());
        int num___ = Integer.parseInt(scan.nextLine());
        int suit___ = Integer.parseInt(scan.nextLine());
        int num____ = Integer.parseInt(scan.nextLine());
        int suit____ = Integer.parseInt(scan.nextLine());
        //flop
        PokerCard c3 = new PokerCard(num__,suit__);
        PokerCard c4 = new PokerCard(num___,suit___);
        PokerCard c5 = new PokerCard(num____,suit____);
        rank(c1,c2,c3,c4,c5);
        
        int num_____ = Integer.parseInt(scan.nextLine());
        int suit_____ = Integer.parseInt(scan.nextLine());
        //turn
        PokerCard c6 = new PokerCard(num_____,suit_____);
        rank(c1,c2,c3,c4,c5,c6);
        
        int num______ = Integer.parseInt(scan.nextLine());
        int suit______ = Integer.parseInt(scan.nextLine());
        //river
        PokerCard c7 = new PokerCard(num______,suit______); 
        rank(c1,c2,c3,c4,c5,c6,c7);
        
        
    }
 
public static double rank(PokerCard c1, PokerCard c2){
       
        long n = 
                
        new PokerRank(
                c1, 
                c2).getRank();
 
        String description = 
        new PokerRank(
                c1, 
                c2).getDescription();
        
        double percent = n;
        percent = ((percent)/max())*100;

        //System.out.println(percent);
        //System.out.println(description);
        
        return percent;
    
}    

public static double rank(PokerCard c1, PokerCard c2, PokerCard c3, PokerCard c4, PokerCard c5){
       
        long n = 
                
        new PokerRank(
                c1, 
                c2,
                c3, c4, c5).getRank();
 
        String description = 
        new PokerRank(
                c1, 
                c2,
                c3, c4, c5).getDescription();
        
        double percent = n;
        percent = (percent/maxFlop())*100;

        //System.out.println(percent);
        //System.out.println(description);
        
        return percent;
}
public static double rank(PokerCard c1, PokerCard c2, PokerCard c3, PokerCard c4, PokerCard c5, PokerCard c6){
       
        long n = 
                
        new PokerRank(
                c1, 
                c2,
                c3, c4, c5, c6).getRank();
 
        String description = 
        new PokerRank(
                c1, 
                c2,
                c3, c4, c5, c6).getDescription();
        
        double percent = n;
        percent = (percent/maxFlop())*100;

        //System.out.println(percent);
       // System.out.println(description); 
        
        return percent;
}
public static double rank(PokerCard c1, PokerCard c2, PokerCard c3, PokerCard c4, PokerCard c5, PokerCard c6, PokerCard c7){
       
        long n = 
                
        new PokerRank(
                c1, 
                c2,
                c3, c4, c5, c6, c7).getRank();
 
        String description = 
        new PokerRank(
                c1, 
                c2,
                c3, c4, c5, c6, c7).getDescription();
        
        double percent = n;
        percent = (percent/maxFlop())*100;

       // System.out.println(percent);
       // System.out.println(description); 
        
        return percent;
}
private static long max(){

    return new PokerRank(
                new PokerCard(14,0), 
                new PokerCard(14,1) ).getRank();
}
private static long min(){

    return new PokerRank(
                new PokerCard(2,0), 
                new PokerCard(8,1) ).getRank();
}
private static long maxFlop(){

    return new PokerRank(
                new PokerCard(14,1), 
                new PokerCard(13,1),
                new PokerCard(12,1),
                new PokerCard(11,1),
                new PokerCard(10,1)).getRank();
}
private static long minFlop(){

    return new PokerRank(
                new PokerCard(2,0), 
                new PokerCard(6,1),
                new PokerCard(3,2),
                new PokerCard(9,3),
                new PokerCard(5,0)).getRank();
}


}

