package holdem;

import java.awt.GridLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JPanel;

/**
 *
 * @author ValentinBura
 */
public class CardsPanel extends JPanel {
    
    
    PokerInterface pokerInterface;
    
    public ArrayList<PokerCard> cards = new ArrayList();
    
    
    JButton preFlop = new JButton("preFlop");
    JButton Flop = new JButton("Flop");
    JButton Turn = new JButton("Turn");
    JButton River = new JButton("River");
    
    JButton Bet = new JButton("Bet");
    JButton Reset = new JButton("Reset");
    
    
    CardsPanel(PokerInterface p){
    
        this.pokerInterface = p;
        
        this.setBackground(UIConstants.TABLE_COLOR);
        
        GridLayout grid = new GridLayout(4,2);
    
        this.setLayout(grid);
    
        this.setSize(100, 100);
        
        this.add(preFlop);
        this.add(Flop);
        this.add(Turn);
        this.add(River);
        this.add(Bet);
        this.add(Reset);
        
        cards.add(new PokerCard(2,2));
        cards.add(new PokerCard(3,2));
        cards.add(new PokerCard(4,2));
        cards.add(new PokerCard(5,2));
        cards.add(new PokerCard(6,2));
        cards.add(new PokerCard(7,2));
        cards.add(new PokerCard(8,2));
        
        
    
        preFlop.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                pokerInterface.preFlop();

            }});
        Flop.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                pokerInterface.Flop();

            }});
        Turn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                pokerInterface.Turn();

            }});
        River.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                pokerInterface.River();

            }});
        Bet.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                pokerInterface.Bet();

            }});
        Reset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                pokerInterface.Reset();

            }});
        
    }
    
    
    
    
    
}