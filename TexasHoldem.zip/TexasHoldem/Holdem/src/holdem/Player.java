package holdem;

import java.util.List;

/**
 * 
 * @author Oscar Stigter
 */
public class Player {

    /** Name. */
    private final String name;

    /** Client application responsible for the actual behavior. */
    //private final Client client;

    /** Hand of cards. */
    private final Hand hand;

    /** Current amount of cash. */
    private int cash;
    
    /** Whether the player has hole cards. */
    private boolean hasCards;

    /** Current bet. */
    private int bet;


    /**
     * Constructor.
     * 
     * @param name
     *            The player's name.
     * @param cash
     *            The player's starting amount of cash.
     * @param client
     *            The client application.
     */
    public Player(String name, int cash) {
        this.name = name;
        this.cash = cash;
        //this.client = client;

        hand = new Hand();

        resetHand();
    }

    public void buyIn(int amount){
        this.cash = amount;
    }
    
    /**
     * Returns the client.
     * 
     * @return The client.
     */
   // public Client getClient() {
     //   return client;
    //}

    /**
     * Prepares the player for another hand.
     */
    public void resetHand() {
        hasCards = false;
        hand.removeAllCards();
        //resetBet();
    }

    /**
     * Resets the player's bet.
     */
 

    /**
     * Sets the hole cards.
     */
    public void setCards(List<PokerCard> cards) {
        hand.removeAllCards();
        if (cards != null) {
            if (cards.size() == 2) {
                hand.addCards(cards);
                hasCards = true;
                System.out.format("[CHEAT] %s's cards:\t%s\n", name, hand);
            } else {
                throw new IllegalArgumentException("Invalid number of cards");
            }
        }
    }

     public void addCard(int phase, PokerCard card) {
        if(phase==1)hand.removeAllCards();
        if (card != null) {
            //if (cards.size() == 2) {
                hand.addCard(phase, card);
                if(phase==2)
                    hasCards = true;
                System.out.format(" %s's cards:\t%s\n", name, hand);
            //} else {
             //   throw new IllegalArgumentException("Invalid number of cards");
            //}
        }
    }
    
    /**
     * Returns whether the player has his hole cards dealt.
     * 
     * @return True if the hole cards are dealt, otherwise false.
     */
    public boolean hasCards() {
        return hasCards;
    }

    /**
     * Returns the player's name.
     * 
     * @return The name.
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the player's current amount of cash.
     * 
     * @return The amount of cash.
     */
    public int getCash() {
        return cash;
    }

    /**
     * Returns the player's current bet.
     * 
     * @return The current bet.
     */
    public int getBet() {
        return bet;
    }
    
    /**
     * Sets the player's current bet.
     * 
     * @param bet
     *            The current bet.
     */
    public void setBet(int bet) {
        this.bet = bet;
    }



    /**
     * Indicates whether this player is all-in.
     * 
     * @return True if all-in, otherwise false.
     */
    public boolean isAllIn() {
        return hasCards() && (cash == 0);
    }

    /**
     * Returns the player's hole cards.
     * 
     * @return The hole cards.
     */
    public PokerCard[] getCards() {
        return hand.getCards();
    }


    
    /**
     * Pays an amount of cash.
     * 
     * @param amount
     *            The amount of cash to pay.
     */
    public void payCash(int amount) {
        if (amount > cash) {
            throw new IllegalStateException("Player asked to pay more cash than he owns!");
        }
        cash -= amount;
    }
    
    /**
     * Wins an amount of money.
     * 
     * @param amount
     *            The amount won.
     */
    public void win(int amount) {
        cash += amount;
    }

    /**
     * Returns a clone of this player with only public information.
     * 
     * @return The cloned player.
     */
    public Player publicClone() {
        Player clone = new Player(name, cash);
        clone.hasCards = hasCards;
        clone.bet = bet;
        //clone.action = action;
        return clone;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        return name;
    }

}
