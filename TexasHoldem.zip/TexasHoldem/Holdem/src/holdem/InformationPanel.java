package holdem;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

/**
 *
 * @author ValentinBura
 */

class InformationPanel extends JPanel {
    

    
    /** The border. */
    private static final Border BORDER = new EmptyBorder(20, 20, 20, 20);
    

    
    public JTextArea textInfo;
    
   
    /**
     * Constructor.
     */
    public InformationPanel() {
        setBorder(BORDER);
        setBackground(UIConstants.TABLE_COLOR);
        setLayout(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        
        
        textInfo = new JTextArea("preFlop");
        textInfo.setBackground(UIConstants.TABLE_COLOR);
        //textInfo.setForeground(UIConstants.TEXT_COLOR);
        textInfo.setEditable(false);
        Font font = textInfo.getFont();
        float size = 30;
        textInfo.setFont( font.deriveFont(size) );
        
        
        //card1Label = new JLabel(CARD_PLACEHOLDER_ICON);
        //card2Label = new JLabel(CARD_PLACEHOLDER_ICON);
        //dealerButton = new JLabel(BUTTON_ABSENT_ICON);
        
 
        gc.gridx = 0;
        gc.gridy = 0;
        gc.gridwidth = 100;
        gc.gridheight = 800;
        gc.weightx = 1.0;
        gc.weighty = 1.0;
        gc.anchor = GridBagConstraints.CENTER;
        gc.fill = GridBagConstraints.NONE;

        add(textInfo, gc);
        
    }
    
    
}
