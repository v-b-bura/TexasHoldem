package holdem;

import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import javax.swing.JPanel;

/**
 *
 * @author ValentinBura
 */
public class SelectPanel extends JPanel {
    
    
    public ArrayList<PokerCard> cards = new ArrayList();
    
    
    private final JButton c2 = new JButton();
    private final JButton d2= new JButton();
    private final JButton h2= new JButton();
    private final JButton s2= new JButton();
    
    private final JButton c3= new JButton();
    private final JButton d3= new JButton();
    private final JButton h3= new JButton();
    private final JButton s3= new JButton();
    
    private final JButton c4= new JButton();
    private final JButton d4= new JButton();
    private final JButton h4= new JButton();
    private final JButton s4= new JButton();
    
    private final JButton c5= new JButton();
    private final JButton d5= new JButton();
    private final JButton h5= new JButton();
    private final JButton s5= new JButton();
    
    private final JButton c6= new JButton();
    private final JButton d6= new JButton();
    private final JButton h6= new JButton();
    private final JButton s6= new JButton();
    
    private final JButton c7= new JButton();
    private final JButton d7= new JButton();
    private final JButton h7= new JButton();
    private final JButton s7= new JButton();
    
    private final JButton c8= new JButton();
    private final JButton d8= new JButton();
    private final JButton h8= new JButton();
    private final JButton s8= new JButton();
    
    private final JButton c9= new JButton();
    private final JButton d9= new JButton();
    private final JButton h9= new JButton();
    private final JButton s9= new JButton();
    
    private final JButton ct= new JButton();
    private final JButton dt= new JButton();
    private final JButton ht= new JButton();
    private final JButton st= new JButton();
    
    private final JButton cj= new JButton();
    private final JButton dj= new JButton();
    private final JButton hj= new JButton();
    private final JButton sj= new JButton();
    
    private final JButton cq= new JButton();
    private final JButton dq= new JButton();
    private final JButton hq= new JButton();
    private final JButton sq= new JButton();
    
    private final JButton ck= new JButton();
    private final JButton dk= new JButton();
    private final JButton hk= new JButton();
    private final JButton sk= new JButton();
    
    private final JButton ca= new JButton();
    private final JButton da= new JButton();
    private final JButton ha= new JButton();
    private final JButton sa= new JButton();
    
    
    SelectPanel(){
    
    try {
        Image imc2 = ImageIO.read(getClass().getResource("c2"));
        c2.setIcon(new ImageIcon(imc2));
        
        Image imd2 = ImageIO.read(getClass().getResource("d2"));
        d2.setIcon(new ImageIcon(imd2));
        
        Image imh2 = ImageIO.read(getClass().getResource("h2"));
        h2.setIcon(new ImageIcon(imh2));
    
        Image ims2 = ImageIO.read(getClass().getResource("s2"));
        s2.setIcon(new ImageIcon(ims2));
    
        
        Image imc3 = ImageIO.read(getClass().getResource("c3"));
        c3.setIcon(new ImageIcon(imc3));
        
        Image imd3 = ImageIO.read(getClass().getResource("d3"));
        d3.setIcon(new ImageIcon(imd3));
        
        Image imh3 = ImageIO.read(getClass().getResource("h3"));
        h3.setIcon(new ImageIcon(imh3));
    
        Image ims3 = ImageIO.read(getClass().getResource("s3"));
        s3.setIcon(new ImageIcon(ims3));
        
        
        Image imc4 = ImageIO.read(getClass().getResource("c4"));
        c4.setIcon(new ImageIcon(imc4));
        
        Image imd4 = ImageIO.read(getClass().getResource("d4"));
        d4.setIcon(new ImageIcon(imd4));
        
        Image imh4 = ImageIO.read(getClass().getResource("h4"));
        h4.setIcon(new ImageIcon(imh4));
    
        Image ims4 = ImageIO.read(getClass().getResource("s4"));
        s4.setIcon(new ImageIcon(ims4));
        
        
        Image imc5 = ImageIO.read(getClass().getResource("c5"));
        c5.setIcon(new ImageIcon(imc5));
        
        Image imd5 = ImageIO.read(getClass().getResource("d5"));
        d5.setIcon(new ImageIcon(imd5));
        
        Image imh5 = ImageIO.read(getClass().getResource("h5"));
        h5.setIcon(new ImageIcon(imh5));
    
        Image ims5 = ImageIO.read(getClass().getResource("s5"));
        s5.setIcon(new ImageIcon(ims5));
        
        
        Image imc6 = ImageIO.read(getClass().getResource("c6"));
        c6.setIcon(new ImageIcon(imc6));
        
        Image imd6 = ImageIO.read(getClass().getResource("d6"));
        d6.setIcon(new ImageIcon(imd6));
        
        Image imh6 = ImageIO.read(getClass().getResource("h6"));
        h6.setIcon(new ImageIcon(imh6));
    
        Image ims6 = ImageIO.read(getClass().getResource("s6"));
        s6.setIcon(new ImageIcon(ims6));
        
        
        Image imc7 = ImageIO.read(getClass().getResource("c7"));
        c7.setIcon(new ImageIcon(imc7));
        
        Image imd7 = ImageIO.read(getClass().getResource("d7"));
        d7.setIcon(new ImageIcon(imd7));
        
        Image imh7 = ImageIO.read(getClass().getResource("h7"));
        h7.setIcon(new ImageIcon(imh7));
    
        Image ims7 = ImageIO.read(getClass().getResource("s7"));
        s7.setIcon(new ImageIcon(ims7));
        
        
        Image imc8 = ImageIO.read(getClass().getResource("c8"));
        c8.setIcon(new ImageIcon(imc8));
        
        Image imd8 = ImageIO.read(getClass().getResource("d8"));
        d8.setIcon(new ImageIcon(imd8));
        
        Image imh8 = ImageIO.read(getClass().getResource("h8"));
        h8.setIcon(new ImageIcon(imh8));
    
        Image ims8 = ImageIO.read(getClass().getResource("s8"));
        s8.setIcon(new ImageIcon(ims8));
        
        
        Image imc9 = ImageIO.read(getClass().getResource("c9"));
        c9.setIcon(new ImageIcon(imc9));
        
        Image imd9 = ImageIO.read(getClass().getResource("d9"));
        d9.setIcon(new ImageIcon(imd9));
        
        Image imh9 = ImageIO.read(getClass().getResource("h9"));
        h9.setIcon(new ImageIcon(imh9));
    
        Image ims9 = ImageIO.read(getClass().getResource("s9"));
        s9.setIcon(new ImageIcon(ims9));
        
        
        Image imct = ImageIO.read(getClass().getResource("ct"));
        ct.setIcon(new ImageIcon(imct));
        
        Image imdt = ImageIO.read(getClass().getResource("dt"));
        dt.setIcon(new ImageIcon(imdt));
        
        Image imht = ImageIO.read(getClass().getResource("ht"));
        ht.setIcon(new ImageIcon(imht));
    
        Image imst = ImageIO.read(getClass().getResource("st"));
        st.setIcon(new ImageIcon(imst));
        
        
        Image imcj = ImageIO.read(getClass().getResource("cj"));
        cj.setIcon(new ImageIcon(imcj));
        
        Image imdj = ImageIO.read(getClass().getResource("dj"));
        dj.setIcon(new ImageIcon(imdj));
        
        Image imhj = ImageIO.read(getClass().getResource("hj"));
        hj.setIcon(new ImageIcon(imhj));
    
        Image imsj = ImageIO.read(getClass().getResource("sj"));
        sj.setIcon(new ImageIcon(imsj));
        
        
        Image imcq = ImageIO.read(getClass().getResource("cq"));
        cq.setIcon(new ImageIcon(imcq));
        
        Image imdq = ImageIO.read(getClass().getResource("dq"));
        dq.setIcon(new ImageIcon(imdq));
        
        Image imhq = ImageIO.read(getClass().getResource("hq"));
        hq.setIcon(new ImageIcon(imhq));
    
        Image imsq = ImageIO.read(getClass().getResource("sq"));
        sq.setIcon(new ImageIcon(imsq));
        
        
        Image imck = ImageIO.read(getClass().getResource("ck"));
        ck.setIcon(new ImageIcon(imck));
        
        Image imdk = ImageIO.read(getClass().getResource("dk"));
        dk.setIcon(new ImageIcon(imdk));
        
        Image imhk = ImageIO.read(getClass().getResource("hk"));
        hk.setIcon(new ImageIcon(imhk));
    
        Image imsk = ImageIO.read(getClass().getResource("sk"));
        sk.setIcon(new ImageIcon(imsk));
        
        
        Image imca = ImageIO.read(getClass().getResource("ca"));
        ca.setIcon(new ImageIcon(imca));
        
        Image imda = ImageIO.read(getClass().getResource("da"));
        da.setIcon(new ImageIcon(imda));
        
        Image imha = ImageIO.read(getClass().getResource("ha"));
        ha.setIcon(new ImageIcon(imha));
    
        Image imsa = ImageIO.read(getClass().getResource("sa"));
        sa.setIcon(new ImageIcon(imsa));
        
        
        c2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(2,1));
                c2.setEnabled(false);
            }
        });
        d2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(2,0));
                d2.setEnabled(false);
            }
        });
        h2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(2,2));
                h2.setEnabled(false);
            }
        });
        s2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(2,3));
                s2.setEnabled(false);
            }
        });
        c3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(3,1));
                c3.setEnabled(false);
            }
        });
        d3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(3,0));
                d3.setEnabled(false);
            }
        });
        h3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(3,2));
                h3.setEnabled(false);
            }
        });
        s3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(3,3));
                s3.setEnabled(false);
            }
        });
        c4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(4,1));
                c4.setEnabled(false);
            }
        });
        d4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(4,0));
                d4.setEnabled(false);
            }
        });
        h4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(4,2));
                h4.setEnabled(false);
            }
        });
        s4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(4,3));
                s4.setEnabled(false);
            }
        });
        c5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(5,1));
                c5.setEnabled(false);
            }
        });
        d5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(5,0));
                d5.setEnabled(false);
            }
        });
        h5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(5,2));
                h5.setEnabled(false);
            }
        });
        s5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(5,3));
                s5.setEnabled(false);
            }
        });
        c6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(6,1));
                c6.setEnabled(false);
            }
        });
        d6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(6,0));
                d6.setEnabled(false);
            }
        });
        h6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(6,2));
                h6.setEnabled(false);
            }
        });
        s6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(6,3));
                s6.setEnabled(false);
            }
        });
        c7.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(7,1));
                c7.setEnabled(false);
            }
        });
        d7.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(7,0));
                d7.setEnabled(false);
            }
        });
        h7.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(7,2));
                h7.setEnabled(false);
            }
        });
        s7.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(7,3));
                s7.setEnabled(false);
            }
        });
        c8.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(8,1));
                c8.setEnabled(false);
            }
        });
        d8.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(8,0));
                d8.setEnabled(false);
            }
        });
        h8.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(8,2));
                h8.setEnabled(false);
            }
        });
        s8.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(8,3));
                s8.setEnabled(false);
            }
        });
        c9.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(9,1));
                c9.setEnabled(false);
            }
        });
        d9.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(9,0));
                d9.setEnabled(false);
            }
        });
        h9.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(9,2));
                h9.setEnabled(false);
            }
        });
        s9.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(9,3));
                s9.setEnabled(false);
            }
        });
        ct.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(10,1));
                ct.setEnabled(false);
            }
        });
        dt.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(10,0));
                dt.setEnabled(false);
            }
        });
        ht.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(10,2));
                ht.setEnabled(false);
            }
        });
        st.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(10,3));
                st.setEnabled(false);
            }
        });
        cj.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(11,1));
                cj.setEnabled(false);
            }
        });
        dj.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(11,0));
                dj.setEnabled(false);
            }
        });
        hj.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(11,2));
                hj.setEnabled(false);
            }
        });
        sj.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(11,3));
                sj.setEnabled(false);
            }
        });
        cq.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(12,1));
                cq.setEnabled(false);
            }
        });
        dq.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(12,0));
                dq.setEnabled(false);
            }
        });
        hq.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(12,2));
                hq.setEnabled(false);
            }
        });
        sq.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(12,3));
                sq.setEnabled(false);
            }
        });
        ck.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(13,1));
                ck.setEnabled(false);
            }
        });
        dk.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(13,0));
                dk.setEnabled(false);
            }
        });
        hk.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(13,2));
                hk.setEnabled(false);
            }
        });
        sk.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(13,3));
                sk.setEnabled(false);
            }
        });
        ca.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(14,1));
                ca.setEnabled(false);
            }
        });
        da.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(14,0));
                da.setEnabled(false);
            }
        });
        ha.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(14,2));
                ha.setEnabled(false);
            }
        });
        sa.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cards.add(new PokerCard(14,3));
                sa.setEnabled(false);
            }
        });
        
        
        
               
    } catch (Exception ex) {
        //PopupFactory factory = PopupFactory.getSharedInstance();
        //Popup popup = factory.getPopup(new JLabel(ex+""), new JLabel(ex+""),0,0);
            System.out.println(ex);
        }
        
        
        GridLayout grid = new GridLayout(4,12);
    
        this.setLayout(grid);
    
        this.setSize(100, 100);
        
        this.add(c2);
        this.add(c3);
        this.add(c4);
        this.add(c5);
        this.add(c6);
        this.add(c7);
        this.add(c8);
        this.add(c9);
        this.add(ct);
        this.add(cj);
        this.add(cq);
        this.add(ck);
        this.add(ca);

        this.add(d2);
        this.add(d3);
        this.add(d4);
        this.add(d5);
        this.add(d6);
        this.add(d7);
        this.add(d8);
        this.add(d9);
        this.add(dt);
        this.add(dj);
        this.add(dq);
        this.add(dk);
        this.add(da);
        
        this.add(h2);
        this.add(h3);
        this.add(h4);
        this.add(h5);
        this.add(h6);
        this.add(h7);
        this.add(h8);
        this.add(h9);
        this.add(ht);
        this.add(hj);
        this.add(hq);
        this.add(hk);
        this.add(ha);
        
        this.add(s2);
        this.add(s3);
        this.add(s4);
        this.add(s5);
        this.add(s6);
        this.add(s7);
        this.add(s8);
        this.add(s9);
        this.add(st);
        this.add(sj);
        this.add(sq);
        this.add(sk);
        this.add(sa);
        
        
        
        this.setVisible(true);
        
    
    }
    
    public void enableControls(){
    
        c2.setEnabled(true);
        c3.setEnabled(true);
        c4.setEnabled(true);
        c5.setEnabled(true);
        c6.setEnabled(true);
        c7.setEnabled(true);
        c8.setEnabled(true);
        c9.setEnabled(true);
        ct.setEnabled(true);
        cj.setEnabled(true);
        cq.setEnabled(true);
        ck.setEnabled(true);
        ca.setEnabled(true);
        
        d2.setEnabled(true);
        d3.setEnabled(true);
        d4.setEnabled(true);
        d5.setEnabled(true);
        d6.setEnabled(true);
        d7.setEnabled(true);
        d8.setEnabled(true);
        d9.setEnabled(true);
        dt.setEnabled(true);
        dj.setEnabled(true);
        dq.setEnabled(true);
        dk.setEnabled(true);
        da.setEnabled(true);
        
        h2.setEnabled(true);
        h3.setEnabled(true);
        h4.setEnabled(true);
        h5.setEnabled(true);
        h6.setEnabled(true);
        h7.setEnabled(true);
        h8.setEnabled(true);
        h9.setEnabled(true);
        ht.setEnabled(true);
        hj.setEnabled(true);
        hq.setEnabled(true);
        hk.setEnabled(true);
        ha.setEnabled(true);
        
        s2.setEnabled(true);
        s3.setEnabled(true);
        s4.setEnabled(true);
        s5.setEnabled(true);
        s6.setEnabled(true);
        s7.setEnabled(true);
        s8.setEnabled(true);
        s9.setEnabled(true);
        st.setEnabled(true);
        sj.setEnabled(true);
        sq.setEnabled(true);
        sk.setEnabled(true);
        sa.setEnabled(true);
    }
    
}
