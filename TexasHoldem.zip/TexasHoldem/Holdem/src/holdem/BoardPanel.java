/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package holdem;

import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author ValentinBura
 */
class BoardPanel extends JPanel {
    
    /** The serial version UID. */
    private static final long serialVersionUID = 8530615901667282755L;

    /** The maximum number of community cards. */
    private static final int NO_OF_CARDS = 5;
    
    
    /** Label with the bet. */
    //public final JLabel betLabel;

    /** Label with the pot. */
    //public final JLabel potLabel;

    /** Labels with the community cards. */
    private final JLabel[] cardLabels;
    
    /** Label with a custom message. */
   // public final JLabel messageLabel;
    
    /**
     * Constructor.
     * 
     * @param controlPanel
     *            The control panel.
     */
    public BoardPanel() {
       
        setBorder(UIConstants.PANEL_BORDER);
        setBackground(UIConstants.TABLE_COLOR);
        setLayout(new GridLayout(1,5));
        //GridBagConstraints gc = new GridBagConstraints();
        
        /*
        JLabel label = new JLabel("Bet");
        label.setForeground(Color.GREEN);
        gc.gridx = 1;
        gc.gridy = 0;
        gc.gridwidth = 1;
        gc.gridheight = 1;
        gc.anchor = GridBagConstraints.CENTER;
        gc.fill = GridBagConstraints.NONE;
        gc.weightx = 1.0;
        gc.weighty = 0.0;
        gc.insets = new Insets(0, 5, 0, 5);
        add(label, gc);
        
        label = new JLabel("Pot");
        label.setForeground(Color.GREEN);
        gc.gridx = 3;
        gc.gridy = 0;
        gc.gridwidth = 1;
        gc.gridheight = 1;
        gc.anchor = GridBagConstraints.CENTER;
        gc.fill = GridBagConstraints.NONE;
        gc.weightx = 1.0;
        gc.weighty = 0.0;
        gc.insets = new Insets(0, 5, 0, 5);
        add(label, gc);
        */
        //betLabel = new JLabel(" ");
        //betLabel.setBorder(UIConstants.LABEL_BORDER);
        //betLabel.setForeground(Color.GREEN);
        //betLabel.setHorizontalAlignment(JLabel.CENTER);
        //gc.gridx = 1;
        //gc.gridy = 1;
        //gc.gridwidth = 1;
       // gc.gridheight = 1;
        //gc.anchor = GridBagConstraints.CENTER;
        //gc.fill = GridBagConstraints.HORIZONTAL;
        //gc.weightx = 1.0;
        //gc.weighty = 0.0;
        //gc.insets = new Insets(5, 5, 5, 5);
        //add(betLabel, gc);

        //potLabel = new JLabel(" ");
        //potLabel.setBorder(UIConstants.LABEL_BORDER);
        //potLabel.setForeground(Color.GREEN);
        //potLabel.setHorizontalAlignment(JLabel.CENTER);
        //gc.gridx = 3;
        //gc.gridy = 1;
        //gc.gridwidth = 1;
        //gc.gridheight = 1;
        //gc.anchor = GridBagConstraints.CENTER;
        //gc.fill = GridBagConstraints.HORIZONTAL;
        //gc.weightx = 1.0;
        //gc.weighty = 0.0;
        //gc.insets = new Insets(5, 5, 5, 5);
        //add(potLabel, gc);

        // The five card positions.
        cardLabels = new JLabel[NO_OF_CARDS];
        for (int i = 0; i < 5; i++) {
            cardLabels[i] = new JLabel(ResourceManager.getIcon("card_placeholder.png"));
            //gc.gridx = i;
            //gc.gridy = 2;
            //gc.gridwidth = 1;
            //gc.gridheight = 1;
            //gc.anchor = GridBagConstraints.CENTER;
            //gc.fill = GridBagConstraints.NONE;
            //gc.weightx = 0.0;
            //gc.weighty = 0.0;
            //gc.insets = new Insets(5, 1, 5, 1);
            add(cardLabels[i]);
        }
                
        setPreferredSize(new Dimension(400, 270));
        
        update(null,0, 0, 0);
    }
    
    
    public void clear(){

                //cardLabels[0] = new JLabel(ResourceManager.getIcon("card_placeholder.png"));
                cardLabels[0].setIcon(ResourceManager.getIcon("card_placeholder.png"));
                
               //cardLabels[1] = new JLabel(ResourceManager.getIcon("card_placeholder.png"));
               cardLabels[1].setIcon(ResourceManager.getIcon("card_placeholder.png"));
               
                //cardLabels[2] = new JLabel(ResourceManager.getIcon("card_placeholder.png"));
               cardLabels[2].setIcon(ResourceManager.getIcon("card_placeholder.png"));
            
                //cardLabels[3] = new JLabel(ResourceManager.getIcon("card_placeholder.png"));
               cardLabels[3].setIcon(ResourceManager.getIcon("card_placeholder.png"));
            
                //cardLabels[4] = new JLabel(ResourceManager.getIcon("card_placeholder.png"));
               cardLabels[4].setIcon(ResourceManager.getIcon("card_placeholder.png"));
            
    }
    
    /**
     * Updates the current hand status.
     * 
     * @param bet
     *            The bet.
     * @param pot
     *            The pot.
     */
    public void update(PokerCard card, int phase, int bet, int pot) {
        if (bet == 0) {
            //betLabel.setText(" ");
        } else {
            //betLabel.setText("$ " + bet);
        }
        if (pot == 0) {
            //potLabel.setText(" ");
        } else {
            //potLabel.setText("$ " + pot);
        }
        //int noOfCards = (cards == null) ? 0 : cards.size();
        //for (int i = 0; i < NO_OF_CARDS; i++) {
            //if(phase==0){
            //    cardLabels[0].setIcon(ResourceManager.getIcon("card_placeholder.png"));
            //    cardLabels[1].setIcon(ResourceManager.getIcon("card_placeholder.png"));
            //}
            //if (phase == 1) {
            //    cardLabels[0].setIcon(ResourceManager.getCardImage(card));
            //    cardLabels[1].setIcon(ResourceManager.getIcon("card_placeholder.png"));
            //}
            //if (phase == 2) {
            //    cardLabels[1].setIcon(ResourceManager.getCardImage(card));
            //}
            if (phase == 3) {
                cardLabels[0].setIcon(ResourceManager.getCardImage(card));
            }
            if (phase == 4) {
               cardLabels[1].setIcon(ResourceManager.getCardImage(card));
            }
            if (phase == 5) {
                cardLabels[2].setIcon(ResourceManager.getCardImage(card));
            }
            if (phase == 6) {
                cardLabels[3].setIcon(ResourceManager.getCardImage(card));
            }
            if (phase == 7) {
                cardLabels[4].setIcon(ResourceManager.getCardImage(card));
            }
}



}
