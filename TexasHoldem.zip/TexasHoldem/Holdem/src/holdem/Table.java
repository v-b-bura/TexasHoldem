
package holdem;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Oscar Stigter
 */
public class Table {
       
    /** The players at the table. */
    private final List<Player> players;
    
    /** The active players in the current hand. */
    //private final List<Player> activePlayers;
    
    /** The deck of cards. */
    public final Deck deck;
    
    /** The community cards on the board. */
    private final List<PokerCard> board;
    
   

    /** The minimum bet in the current hand. */
    private int minBet;
    
    /** The current bet in the current hand. */
    public int bet;
    
    public int pot;
    
    public int stack;

       
    public boolean playing = true;
    
    public PokerCard holeCard1;
    public PokerCard holeCard2;
    public PokerCard flopCard1;
    public PokerCard flopCard2;
    public PokerCard flopCard3;
    public PokerCard turnCard;
    public PokerCard riverCard;
    
    
    PokerInterface pokerInterface;
    
    BoardPanel boardPanel;
    
    /**
     * Constructor.
     * 
     * @param bigBlind
     *            The size of the big blind.
     */
    public Table(PokerInterface Interface, BoardPanel Board) {

        players = new ArrayList<Player>();
        //activePlayers = new ArrayList<Player>();
        pokerInterface = Interface;
        boardPanel = Board;
        deck = new Deck();
        board = new ArrayList<PokerCard>();

    }
    
    /**
     * Adds a player.
     * 
     * @param player
     *            The player.
     */
    public void addPlayer(Player player) {
        players.add(player);
        //activePlayers.add(player);
    }
    
    /**
     * Main game loop.
     */
    public void preFlop() {
        resetHand();
    
        //playPreFlop(holeCard1, holeCard2);
        playPreFlop(1,holeCard1);
        
        playPreFlop(2,holeCard2);
        

    }
    
    public String flop(){
        //playFlop(flopCard1, flopCard2, flopCard3);
        playFlop(1,flopCard1);
        playFlop(2,flopCard2);
        String s = playFlop(3,flopCard3); 
        
        pokerInterface.playerUpdated(players.get(0));

        pokerInterface.boardUpdated(flopCard1,3, bet, pot);
        pokerInterface.boardUpdated(flopCard2,4, bet, pot);
        pokerInterface.boardUpdated(flopCard3,5, bet, pot);
        
        return s;
   }
    
    public String turn(){
        String s = playTurn(turnCard); 
        
        pokerInterface.playerUpdated(players.get(0));
        pokerInterface.boardUpdated(turnCard,6, bet, pot);
        
        return s;
    }
    
    public String river(){
        String s = playRiver(riverCard); 
        
        pokerInterface.playerUpdated(players.get(0));
        pokerInterface.boardUpdated(riverCard,7, bet, pot);
        
            // Game over.
        board.clear();

        bet = 0;


        players.get(0).resetHand();
        
        return s;
    }

    public String playPreFlop(int phase, PokerCard c){

        dealHoleCard(phase, c);
        if(phase==2){
            
            
            //boardPanel.update(c, phase, bet, pot);
            
            pokerInterface.playerUpdated(players.get(0));
            
            pokerInterface.boardPanel.update(c, phase, bet, pot);
            
            return "";
                    //doBettingRound(phase, pokerInterface.getStrength(phase), pot, bet);
            
        }
        return "";
    }
    
    
    public String playFlop(int phase, PokerCard c){
    
            //bet = 0;
            dealFlop(phase, c);
            
            

            if(phase==5){
                //pokerInterface.boardUpdated(holeCard1,1, bet, pot);
            //pokerInterface.boardUpdated(holeCard2,2, bet, pot);
                pokerInterface.boardPanel.update(c, phase, bet, pot);
                
                return "";
                        //doBettingRound(phase, pokerInterface.getStrength(phase), pot,bet);
            }  
            return "";
    }
    

    
    public String playTurn(PokerCard c){
 
                bet = 0;
                dealTurn(c);
                //minBet = 2 * bigBlind;
                
                pokerInterface.boardPanel.update(c, 6, bet, pot);
                
                
                
                return "";
                        //doBettingRound(6, pokerInterface.getStrength(6), pot,bet);
    }
    
    public String playRiver(PokerCard c){   

                    bet = 0;
                    dealRiver(c);
                    
                    pokerInterface.boardPanel.update(c, 7, bet, pot);
                    
                    return "";
                            //doBettingRound(7, pokerInterface.getStrength(7), pot,bet);


    }
    
    /**
     * Resets the game for a new hand.
     */
    private void resetHand() {
        // Clear the board.
        board.clear();

    }

  
    public void dealHoleCard(int phase, PokerCard c) {

        for (Player player : players) {

            c = deck.deal(c.getValue(), c.getSuit());
            if(c!=null){
                player.addCard(phase, c);                
            }else{pokerInterface.errorMessage("card unavailable");}
        }


    }
    
    /**
     * Deals a number of community cards.
     * 
     * @param phaseName
     *            The name of the phase.
     * @param noOfCards
     *            The number of cards to deal.
     */
    private void dealFlop(int phase, PokerCard c) {

        if(c!=null){
                            board.add(deck.deal(c.getValue(),c.getSuit()));
                            pokerInterface.boardUpdated(c,phase, bet, pot);             
            }else{pokerInterface.errorMessage("card unavailable");}
    }
    private void dealTurn(PokerCard c) {

             if(c!=null){
                            board.add(deck.deal(c.getValue(),c.getSuit()));
                            pokerInterface.boardUpdated(c,6, bet, pot);             
            }else{pokerInterface.errorMessage("card unavailable");}


    }
    private void dealRiver(PokerCard c) {

             if(c!=null){
                            board.add(deck.deal(c.getValue(),c.getSuit()));
                            pokerInterface.boardUpdated(c,7, bet, pot);             
            }else{pokerInterface.errorMessage("card unavailable");}
            

    }
    
    /**
     * Performs a betting round.
     */
    public String doBettingRound(int phase, double handPercentage, int pot, int bet) {
       
        
        handPercentage = handPercentage*0.01;
        
        double amount = pot + bet;
        //double amount = pot;
        
        double percentage = (double)(bet/amount);
        
        System.out.println("hand "+handPercentage);
        System.out.println("pot "+percentage);
        
        
        int raise = (int)Math.floor((((handPercentage-0.01)-percentage))*pot + bet);
        System.out.println("raise "+raise+"bet "+bet);
        
        
        if(handPercentage - percentage > 0.1)return "raise to "+ raise;
        
        if(handPercentage - percentage > 0)return "call";
        
        if(handPercentage - percentage < 0)return "fold";
                              
        return "";
    }
    
    public static String doBettingRound(int phase, int pot, int bet, double handPercentage) {
       
            handPercentage = handPercentage*0.01;
        
            double amount = pot + bet;
        
            double percentage = (double)(bet/amount);
        
            //System.out.println("hand "+handPercentage);
            //System.out.println("pot "+percentage);
        
        
            int raise = (int)Math.floor((((handPercentage-0.01)-percentage))*pot + bet);
            //System.out.println("raise "+raise+"bet "+bet);
        
        
            if(handPercentage - percentage > 0.1)return "raise to " + raise;
        
            if(handPercentage - percentage > 0)return "call";
        
            if(handPercentage - percentage < 0)return "fold";
                              
            return "";
        
    }  
}
