package holdem;

import java.awt.GridLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JPanel;

/**
 *
 * @author ValentinBura
 */
public class CardsPanel extends JPanel {
    
    
    PokerInterface pokerInterface;
    
    public ArrayList<PokerCard> cards = new ArrayList();
    
    JButton Reset = new JButton("Reset ");
    JButton Next = new JButton("Next >> ");    
    
    JButton Bet = new JButton("Bet "); 
    JButton TenPot = new JButton("Ten Pot");
    JButton FiveBet = new JButton("Bet Five");
    JButton OneBet = new JButton("Bet One ");    
    
    CardsPanel(PokerInterface p){
    
        this.pokerInterface = p;
        
        this.setBackground(UIConstants.TABLE_COLOR);
        
        GridLayout grid = new GridLayout(2,3);
    
        this.setLayout(grid);
    
        this.setSize(50, 10);
        
        this.add(Next);
        this.add(Reset);
        this.add(Bet);
        this.add(TenPot);
        this.add(FiveBet);
        this.add(OneBet);
        
        cards.add(new PokerCard(2,2));
        cards.add(new PokerCard(3,2));
        cards.add(new PokerCard(4,2));
        cards.add(new PokerCard(5,2));
        cards.add(new PokerCard(6,2));
        cards.add(new PokerCard(7,2));
        cards.add(new PokerCard(8,2));
        
        Reset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                pokerInterface.Reset();

            }});

        Next.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                pokerInterface.Next();
            }});

        Bet.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                pokerInterface.Bet();
            }});
        
        TenPot.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                pokerInterface.pot = 10;
            }});
        
        FiveBet.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                pokerInterface.bet += 5;
            }});        
        
        OneBet.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                pokerInterface.bet += 1;
            }});               
    }   
}