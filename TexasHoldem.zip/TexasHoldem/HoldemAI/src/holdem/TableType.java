
package holdem;

/**
 * Supported table types (betting structures).
 * 
 * @author Oscar Stigter
 */
public enum TableType {
      
    /** No-Limit Texas Hold'em. */
    NO_LIMIT("No-Limit"),
    
    ;
    
    /** Display name. */
    private String name;
    
    /**
     * Constructor.
     * 
     * @param name
     *            The display name.
     */
    TableType(String name) {
        this.name = name;
    }
    
    /**
     * Returns the display name.
     * 
     * @return The display name.
     */
    public String getName() {
        return name;
    }

}
