package holdem;

import java.util.*;
import java.awt.*;
import javax.swing.*;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.JFrame;
import java.util.Set;
import java.util.List;



public class PokerInterface extends JFrame {

    private Table table;
    
    /** The players at the table. */
    //private Map<String, Player> players;
    
   
    /** The board panel. */
    public BoardPanel boardPanel;

    
    /** The player panels. */
    private PlayerPanel playerPanel;
    
    /** The human player. */
    //private Player humanPlayer;
     
    public InformationPanel infoPanel; 

    public StatsPanel statsPanel; 
    
    public OutsPanel outsPanel;
    
    public CardsPanel cardsPanel;
    

    
    public BetPanel betPanel;
    
    
    public int position = -1;
    public int tabletype = -1;
    
    public int phase = 1;
    
    public int pot = 1;
    public int bet = 1;
    
    private static List<PokerCard> cardList = new ArrayList();
    
    //private static HoldemRanking holdemRanking = new HoldemRanking();
    
    private PokerCard holeCard1;
    private PokerCard holeCard2;
    private PokerCard flopCard1;
    private PokerCard flopCard2;
    private PokerCard flopCard3;
    private PokerCard turnCard;
    private PokerCard riverCard;
    
    int holeCard1Denum = -1;
    int holeCard1Suit = -1; 
    
    int holeCard2Denum = -1;
    int holeCard2Suit = -1; 
    
    
    int flopCard1Denum = -1;
    int flopCard1Suit = -1; 
    
    int flopCard2Denum = -1;
    int flopCard2Suit = -1; 
    
    int flopCard3Denum = -1;
    int flopCard3Suit = -1; 
    
    
    int turnCardDenum = -1;
    int turnCardSuit = -1; 
    
    
    int riverCardDenum = -1;
    int riverCardSuit = -1; 
       
    JButton Next = new JButton();
    
    
    
    
    /**
     * Constructor.
     */
    public PokerInterface() {
        super("No Limit Texas Hold'em");
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(UIConstants.TABLE_COLOR);
        setLayout(new GridLayout(4,4));
        
        //controlPanel = new ControlPanel(TABLE_TYPE);

        cardsPanel = new CardsPanel(this);
        //selectPanel = new SelectPanel();
        
        cardsPanel.setSize(60, 20);
        
        //panel.add(selectPanel);
        //panel.add(cardsPanel);
        
        
        betPanel = new BetPanel(this);
        

        
        boardPanel = new BoardPanel();        

        
        //players = new LinkedHashMap<String, Player>();
        //humanPlayer = new Player("Player", CASH);
        
        infoPanel = new InformationPanel();
       
        statsPanel = new StatsPanel();
        
        outsPanel = new OutsPanel();
        
        //players.put("Player", humanPlayer);

        table = new Table(this, boardPanel);
        //for (Player player : players.values()) {
        //table.addPlayer(humanPlayer);
        //table.addPlayer(new Player("Eddie", STARTING_CASH, this));

        //}
        
        playerPanel = new  PlayerPanel();
        //int i = 0;
        //for (Player player : players.values()) {
            
            //PlayerPanel panel = new PlayerPanel();
            playerPanel.update();
            //switch (i++) {
                //case 0:
                    // North position.
            //addComponent(playerPanel);
  

        addComponent(cardsPanel);
        addComponent(betPanel);
        addComponent(boardPanel);            
        addComponent(playerPanel);
        //JPanel panel_ = new JPanel();
        //panel_.setLayout(new GridLayout(1,2));
    
                
        addComponent(infoPanel);
        addComponent(statsPanel);
        addComponent(outsPanel);   
        
        //addComponent(panel_);
        
        
        
        JMenuBar menu = new JMenuBar();

        JButton _six = new JButton("6seat");
        JButton _nine = new JButton("9seat");        
        JLabel mlabel = new JLabel("|");        
        JButton _1 = new JButton("1");
        JButton _2 = new JButton("2");
        JButton _3 = new JButton("3");
        JButton _4 = new JButton("4");
        JButton _5 = new JButton("5");
        JButton _6 = new JButton("6");
        JButton _7 = new JButton("7");
        JButton _8 = new JButton("8");
        JButton _9 = new JButton("9");        
 
        _six.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
              tabletype = 6;  
            }});
        _nine.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                tabletype = 9;
            }});        
        _1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                position = 1;
            }});
        _2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                position = 2;                
            }});
        _3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                position = 3;                
            }});
        _4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                position = 4;                
            }});
        _5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                position = 5;                
            }});
        _6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                position = 6;                
            }});
        _7.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                position = 7;                
            }});
        _8.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                position = 8;                
            }});
        _9.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                position = 9;                
            }});



        
        menu.add(_six);
        menu.add(_nine);
        menu.add(mlabel);
        menu.add(_1);
        menu.add(_2);
        menu.add(_3);        
        menu.add(_4);
        menu.add(_5);
        menu.add(_6);  
        menu.add(_7);
        menu.add(_8);
        menu.add(_9);          

        
        setJMenuBar(menu);
        
        
        initializeListeners();

        

        // Show the frame.
        boardPanel.setVisible(true);
        pack();
        setSize(500,560);
        setResizable(false);
        setLocation(0,0);
        setVisible(true);
                        
    }
        
    public void Next(){
        switch(phase){
            case 1:
                preFlop();
                break;
            case 3:
                Flop();  
                break;
            case 6:
                Turn();
                break;
            case 7: 
                River();
                break;
            case 8:
                Reset();
                break;                
        } 
    }
       
    public void Bet(){
        
                    
                    recommend();
                    
                    betPanel.bet.setText("");
                    betPanel.pot.setText("");
                    bet = 0;
                    pot = 0;
    }   
    public void preFlop(){       
                        
                    String card1 = Match.getCard(tabletype, position, phase);
                    phase++;
                    
                    String card2 = Match.getCard(tabletype, position, phase);                    
                    phase++;    
                    
                    //PokerCard c1 = cards.get(0);
                    //PokerCard c2 = cards.get(1);
                      
                    PokerCard c1 = new PokerCard(getDenum(card1),getSuit(card1));
                    PokerCard c2 = new PokerCard(getDenum(card2),getSuit(card2));
                    

                    
                    holeCard1 = c1;
                    holeCard2 = c2;
                    
                    cardList.add(holeCard1);
                    cardList.add(holeCard2);
                    
                    table.holeCard1 = holeCard1;
                    table.holeCard2 = holeCard2;
                       
                    playerPanel.hasCards = true;
                    playerPanel.cards[0] = holeCard1;
                    playerPanel.cards[1] = holeCard2;
                    
                    table.playPreFlop(1, holeCard1);
                    table.playPreFlop(2, holeCard2);
                                        
    }
    public void Flop(){
                    //ArrayList<PokerCard> cards = selectPanel.cards;

                    String card1 = Match.getCard(tabletype, position, phase);
                    phase++;
                    
                    String card2 = Match.getCard(tabletype, position, phase);
                    phase++;  
                    
                    String card3 = Match.getCard(tabletype, position, phase);                    
                    phase++;
                    
                    PokerCard c1 = new PokerCard(getDenum(card1),getSuit(card1));
                    PokerCard c2 = new PokerCard(getDenum(card2),getSuit(card2));
                    PokerCard c3 = new PokerCard(getDenum(card3),getSuit(card3));
                    

                    flopCard1 = c1;
                    flopCard2 = c2;
                    flopCard3 = c3;
                                       
                    table.flopCard1 = flopCard1;
                    table.flopCard2 = flopCard2;
                    table.flopCard3 = flopCard3;
                    
                    table.playFlop(3, flopCard1);
                    table.playFlop(4, flopCard2);
                    table.playFlop(5, flopCard3);
                    
    }
    public void Turn(){
                    //ArrayList<PokerCard> cards = selectPanel.cards;
        
                    String card1 = Match.getCard(tabletype, position, phase);
                    phase++;    
                                        
                    PokerCard c1 = new PokerCard(getDenum(card1),getSuit(card1));
                      

        
                    turnCard = c1;
               
                    table.turnCard = turnCard;
                    
                    table.playTurn(turnCard);
                    
                    //table.turn();

    }
    public void River(){
                    //ArrayList<PokerCard> cards = selectPanel.cards;
        
                    //PokerCard c1 = cards.get(6);
                      
                    String card1 = Match.getCard(tabletype, position, phase);
                    
                    phase++;
                    
                    PokerCard c1 = new PokerCard(getDenum(card1),getSuit(card1));
                    
                    riverCard = c1;
                                       
                    table.riverCard = riverCard;
                    
                    table.playRiver(c1);
                    
    }
    public void Reset(){
       
                    boardPanel.clear();
                    
                    playerPanel.hasCards = false;
                    playerPanel.update();
                    
                    table.boardPanel.clear();
                    
                    
                    holeCard1 = null;
                    holeCard2 = null;
                    flopCard1 = null;
                    flopCard2 = null;
                    flopCard3 = null;
                    turnCard = null;
                    riverCard = null;
                                       
                    cardList.clear();
                    cardsPanel.cards.clear(); 

                    
                    table.deck.reset();

                    phase = 1;
    }
    
    private int getDenum(String card){
    
        String v = card.substring(1, 2);
        
        if(v.compareTo("2")==0)return 2;
        if(v.compareTo("3")==0)return 3;
        if(v.compareTo("4")==0)return 4;
        if(v.compareTo("5")==0)return 5;
        if(v.compareTo("6")==0)return 6;
        if(v.compareTo("7")==0)return 7;
        if(v.compareTo("8")==0)return 8;
        if(v.compareTo("9")==0)return 9;
        if(v.compareTo("t")==0)return 10;
        if(v.compareTo("j")==0)return 11;
        if(v.compareTo("q")==0)return 12;
        if(v.compareTo("k")==0)return 13;
        if(v.compareTo("a")==0)return 14;
        
        return 0;
    }
    
    private int getSuit(String card){
    
        String s = card.substring(0, 1);
           
        if(s.compareTo("c")==0)return 1;
        if(s.compareTo("d")==0)return 0;
        if(s.compareTo("h")==0)return 2;
        if(s.compareTo("s")==0)return 3;
               
        return 4;
    }
    
    
    private void initializeListeners(){
    
        
        
    }
        
    
    
    private void actionDenum(int phase, int denum) {
        
        switch(phase){
            case 1:
                //System.out.println(denum);
                holeCard1Denum = denum;
                holeCard1 = new PokerCard(holeCard1Denum, holeCard1Suit);
                break;
            case 2:
                holeCard2Denum = denum;
                holeCard2 = new PokerCard(holeCard2Denum, holeCard2Suit);
                break;    
            case 3:
                flopCard1Denum = denum;
                flopCard1 = new PokerCard(flopCard1Denum, flopCard1Suit);
                break;
            case 4:
                flopCard2Denum = denum; 
                flopCard2 = new PokerCard(flopCard2Denum, flopCard2Suit);
                break;
            case 5:
                flopCard3Denum = denum;
                flopCard3 = new PokerCard(flopCard3Denum, flopCard3Suit);
                break;
            case 6:
                turnCardDenum = denum; 
                turnCard = new PokerCard(turnCardDenum, turnCardSuit);
                break;
            case 7:
                riverCardDenum = denum; 
                riverCard = new PokerCard(riverCardDenum, riverCardSuit);
                break;    
        }
        
        //play();
        
        
    }
    private void actionSuit(int phase, int suit) {
        switch(phase){
            case 1:
                holeCard1Suit = suit; 
                break;
            case 2:
                holeCard2Suit = suit; 
                break;    
            case 3:
                flopCard1Suit = suit; 
                break;
            case 4:
                flopCard2Suit = suit; 
                break;
            case 5:
                flopCard3Suit = suit; 
                break;
            case 6:
                turnCardSuit = suit; 
                
                break;
            case 7:
                riverCardSuit = suit; 
                break;    
        }      
    }
    
    
    public double getStrength(int phase){
    
        //HoldemRanking ranking = new HoldemRanking(); 
        
        switch(phase){
            case 2:               
                return HoldemRanking.rank(holeCard1, holeCard2);

            case 5:
                return HoldemRanking.rank(holeCard1, holeCard2, flopCard1, flopCard2, flopCard3);
 
                
            case 6:
                return HoldemRanking.rank(holeCard1, holeCard2, flopCard1, flopCard2, flopCard3, turnCard);
       
 
            case 7:
                return HoldemRanking.rank(holeCard1, holeCard2, flopCard1, flopCard2, flopCard3, turnCard, riverCard);
         
        }
        
        return 0;
    }
    

    
    private String recommend(){
    
            if(phase==2){
                
                infoPanel.textInfo.setText(
                    new PokerRank(holeCard1, holeCard2)+ "\n" +
                    table.doBettingRound(2, HoldemRanking.rank(holeCard1, holeCard2), pot, bet)
                            );
                statsPanel.textInfo.setText(
                
                    "You may be up against: \n" +
                            (new PokerRank(holeCard1, holeCard2)).computeAdversary()
                );
                /*
                outsPanel.textInfo.setText(
                
                    "You may improve to: \n" 
                        + (new PokerRank(holeCard1, holeCard2)).computeOuts(2)
                );
                */
            
            }
            if(phase==3){
                
                
                infoPanel.textInfo.setText(
                    new PokerRank(holeCard1, holeCard2, flopCard1, flopCard2, flopCard3)+ "\n" +
                    table.doBettingRound(5, HoldemRanking.rank(holeCard1, holeCard2, flopCard1, flopCard2, flopCard3), pot, bet)                
                );
                statsPanel.textInfo.setText(
                                    "You may be up against: \n" +
                            (new PokerRank(holeCard1, holeCard2, flopCard1, flopCard2, flopCard3)).computeAdversary()
                );
                outsPanel.textInfo.setText(
                
                    "You may improve to: \n" 
                        + (new PokerRank(holeCard1, holeCard2, flopCard1, flopCard2, flopCard3)).computeOuts(3)
                );
                
            }
            if(phase==4){
                
                infoPanel.textInfo.setText(
                    new PokerRank(holeCard1, holeCard2, flopCard1, flopCard2, flopCard3, turnCard)+ "\n" +
                    table.doBettingRound(6, HoldemRanking.rank(holeCard1, holeCard2, flopCard1, flopCard2, flopCard3, turnCard), pot, bet)                
                );
                statsPanel.textInfo.setText(
                    "You may be up against: \n" +
                            (new PokerRank(holeCard1, holeCard2, flopCard1, flopCard2, flopCard3,turnCard)).computeAdversary()
                );
                outsPanel.textInfo.setText(
                
                    "You may improve to: \n" 
                        + (new PokerRank(holeCard1, holeCard2, flopCard1, flopCard2, flopCard3,turnCard)).computeOuts(4)
                );
            }
            if(phase==5){
                
                infoPanel.textInfo.setText(
                    new PokerRank(holeCard1, holeCard2, flopCard1, flopCard2, flopCard3, turnCard, riverCard)+ "\n" +
                    table.doBettingRound(7, HoldemRanking.rank(holeCard1, holeCard2, flopCard1, flopCard2, flopCard3, turnCard, riverCard), pot, bet)                
                );
                statsPanel.textInfo.setText(
                    "You may be up against: \n" +
                            (new PokerRank(holeCard1, holeCard2, flopCard1, flopCard2, flopCard3,turnCard,riverCard)).computeAdversary()
                );
                outsPanel.textInfo.setText(
                
                    "You may improve to: \n"
                        + (new PokerRank(holeCard1, holeCard2, flopCard1, flopCard2, flopCard3,turnCard,riverCard)).computeOuts(5)
                );
            }
    
    
        return "";
    }

 
            
    public void errorMessage(String error){    
        JOptionPane.showMessageDialog(null, error, "InfoBox: " + error, JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void play(int phase){
                        
        boardPanel.setVisible(true);
        //specify the blinds
        //blindsVisible();
                 
        
        //boardPanel.betLabel.setText("");
        
        // Start the game.
        //while(true){
        if(phase==1){
            table.holeCard1 = holeCard1; 
            
            table.pot = this.pot;
            table.bet = this.bet;
            
           
            table.playPreFlop(1,holeCard1);
            
            //infoPanel.recommendLabel.setText("wait");
            
            this.phase = 1;
        }
        if(phase==2){
            table.holeCard2 = holeCard2;
            
            table.pot = this.pot;
            table.bet = this.bet;
            
            String action = table.playPreFlop(2,holeCard2); 
           
            this.phase = 2;
            recommend();
            
           
        }
        //System.out.println(holeCard1+" "+holeCard2);
        
           
        if(phase==3){
            table.flopCard1 = flopCard1;
            //infoPanel.recommendLabel.setText("wait");
            
            this.phase = 3;
        }
        if(phase==4){
            table.flopCard2 = flopCard2;
            //infoPanel.recommendLabel.setText("wait");
            
            this.phase = 4;
        }
        if(phase==5){
            
            pot += bet;
            bet = 0;           
            //boardPanel.betLabel.setText(""+bet);
            //boardPanel.potLabel.setText(""+pot);
            
            table.flopCard3 = flopCard3;
               
            table.pot = pot;
            table.bet = bet;
            
            String action = table.flop();
            
            this.phase = 5;
            recommend();
            
            
        }
        if(phase==6){
            
            pot += bet;
            bet = 0;           
            //boardPanel.betLabel.setText(""+bet);
            //boardPanel.potLabel.setText(""+pot);
            
            table.turnCard = turnCard;
        
            table.pot = pot;
            table.bet = bet;
            
            String action = table.turn();
            
            this.phase = 6;
            
            recommend();
            
            
        }
        if(phase==7){
            
            
            pot += bet;
            bet = 0;           
            //boardPanel.betLabel.setText(""+bet);
            //boardPanel.potLabel.setText(""+pot);
            
            table.riverCard = riverCard;
        
            table.pot = pot;
            table.bet = bet;
            
            String action = table.river();
            
            this.phase = 7;
            recommend();
            
            
         
       }
    }

    
    
    
    static PokerCard fromString(String s){
            int suit = -1;
            int rank = -1;
        
            String cs = s.substring(0, 1);
            String cr = s.substring(1, 2);
          
            switch(cs){
                case "d":
                    suit = 0;
                    break;
                case "c":
                    suit = 1;
                    break;
                case "s":
                    suit = 3;
                    break;
                case "h":
                    suit = 2;
                    break;
            }
            switch(cr){
                case "2":
                    rank = 2;
                    break;
                case "3":
                    rank = 3;
                    break;
                case "4":
                    rank = 4;
                    break;
                case "5":
                    rank = 5;
                    break;
                case "6":
                    rank = 6;
                    break;
                case "7":
                    rank = 7;
                    break;
                case "8":
                    rank = 8;
                    break;
                case "9":
                    rank = 9;
                    break;
                case "t":
                    rank = 10;
                    break;
                case "j":
                    rank = 11;
                    break;
                case "q":
                    rank = 12;
                    break;
                case "k":
                    rank = 13;
                    break;    
                case "a":
                    rank = 14;
                    break;    
            }
            return new PokerCard(rank, suit);
    }
     public static String doBettingRound(int phase, int pot, int bet, double handPercentage) {
       
            handPercentage = handPercentage*0.01;
        
            double amount = pot + bet;
        
            double percentage = (double)(bet/amount);
        
            //System.out.println("hand "+handPercentage);
            //System.out.println("pot "+percentage);
        
        
            int raise = (int)Math.floor((((handPercentage-0.01)-percentage))*pot + bet);
            //System.out.println("raise "+raise+"bet "+bet);
        
        
            if(handPercentage - percentage > 0.1)return "optimum bet " + raise;
        
            if(handPercentage - percentage > 0)return "call";
        
            if(handPercentage - percentage < 0)return "fold";
                              
            return "";
        
    } 
    static String play(int phase, int pot, int bet, PokerCard c){

        if(phase==1){
            
            cardList.add(c);
            //infoPanel.recommendLabel.setText("wait");
            
            //this.phase = 1;
        }
        if(phase==2){
            //table.holeCard2 = c1;
            
            //table.pot = pot;
            //table.bet = bet;
            
            //String action = table.playPreFlop(2,holeCard2); 
           
            //this.phase = 2;
            cardList.add(c);
            
            return doBettingRound(phase,pot,bet,HoldemRanking.rank(cardList.get(0), cardList.get(1)));
            
            //recommend(phase,pot,bet,cardList);
            
           
        }
        //System.out.println(holeCard1+" "+holeCard2);
        
           
        if(phase==3){
            //table.flopCard1 = c1;
            //infoPanel.recommendLabel.setText("wait");
            
            //this.phase = 3;
            cardList.add(c);
        }
        if(phase==4){
            //table.flopCard2 = c1;
            //infoPanel.recommendLabel.setText("wait");
            cardList.add(c);
            //this.phase = 4;
        }
        if(phase==5){
            
            //pot += bet;
            //bet = 0;           
            //boardPanel.betLabel.setText(""+bet);
            //boardPanel.potLabel.setText(""+pot);
            
            //table.flopCard3 = c1;
               
            //table.pot = pot;
            //table.bet = bet;
            
            //table.flop();
            cardList.add(c);
            //this.phase = 5;
            
            return doBettingRound(phase,pot,bet,HoldemRanking.rank(cardList.get(0), cardList.get(1), 
                    cardList.get(2), cardList.get(3), cardList.get(4)));
            
            //recommend(phase,pot,bet,cardList);
            
            
        }
        if(phase==6){
            
            //pot += bet;
            //bet = 0;           
            //boardPanel.betLabel.setText(""+bet);
            //boardPanel.potLabel.setText(""+pot);
            
            //table.turnCard = turnCard;
        
            //table.pot = pot;
            //table.bet = bet;
            
            //String action = table.turn();
            
            //this.phase = 6;
            
            cardList.add(c);
            
            return doBettingRound(phase,pot,bet,HoldemRanking.rank(cardList.get(0), cardList.get(1), 
                    cardList.get(2), cardList.get(3), cardList.get(4), cardList.get(5)));
            
            //recommend(phase,pot,bet,cardList);
            
            
        }
        if(phase==7){
            
            
            cardList.add(c);
            
            return doBettingRound(phase,pot,bet,HoldemRanking.rank(cardList.get(0), cardList.get(1), 
                    cardList.get(2), cardList.get(3), cardList.get(4), cardList.get(5), cardList.get(6)));
            
            //recommend();
            
            
         
       }
       return ""; 
    }
    public static void main(String[] args) {
        
        
        new PokerInterface();
        
                                           
        
        //new PokerInterface();
    }


  
    public void boardUpdated(PokerCard card,int phase, int bet, int pot) {
        boardPanel.update(card,phase, bet, pot);
    }


    public void playerUpdated() {
            playerPanel.update();
    }


    public void playerActed() {
        String name = "player";
        //PlayerPanel playerPanel = playerPanels.get(name);
        if (playerPanel != null) {
            playerPanel.update();

        } else {
            throw new IllegalStateException(
                    String.format("No PlayerPanel found for player '%s'", name));
        }
    }

    private void addComponent(Component component) {
        
        getContentPane().add(component);
    }



}