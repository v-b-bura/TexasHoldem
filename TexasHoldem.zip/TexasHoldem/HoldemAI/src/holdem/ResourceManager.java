package holdem;

import java.awt.Color;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

abstract class ResourceManager {
    
    private static final String IMAGE_PATH_FORMAT = "card_%s.png"; 
    
    public static ImageIcon getCardImage(PokerCard card) {

        int sequenceNr = card.getSuit() * 13 + card.getValue();
        String sequenceNrString = String.valueOf(sequenceNr);
        if (sequenceNrString.length() == 1) {
            sequenceNrString = "0" + sequenceNrString;
        }
        String path = String.format(IMAGE_PATH_FORMAT, sequenceNrString);
        return getIcon(path);
    }
    

    
    public static ImageIcon getIcon(String path) {
        URL url = ResourceManager.class.getResource(path);
        if (url != null) {
            return new ImageIcon(url);
        } else {
            throw new RuntimeException("Resource file not found: " + path);
        }
    }
    
}
interface UIConstants {

    /** The table color. */
    Color TABLE_COLOR = new Color(0, 128, 0); // Dark green

    /** The text color. */
    Color TEXT_COLOR = Color.GREEN;

    /** The border used around labels. */
    Border LABEL_BORDER = new LineBorder(Color.BLACK, 1);
    
    /** The border used around panels. */
    Border PANEL_BORDER = new CompoundBorder(
            new LineBorder(Color.BLACK, 1), new EmptyBorder(10, 10, 10, 10));

}

