/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package holdem;

import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 *
 * @author ValentinBura
 */
public class BetPanel extends JPanel{
    
    
    final PokerInterface p;
    
    JTextArea lbl = new JTextArea("Pot");
    
    public JTextArea pot = new JTextArea();
        
    JTextArea lbl_ = new JTextArea("Bet");
   
    public JTextArea bet = new JTextArea();
    
    BetPanel(PokerInterface pokerInterface){
    
        Font font = pot.getFont();
        float size = 20;
        pot.setFont( font.deriveFont(size) );
        bet.setFont( font.deriveFont(size) );
        pot.setEditable(false);
        bet.setEditable(false);
        pot.setBackground(UIConstants.TABLE_COLOR);
        bet.setBackground(UIConstants.TABLE_COLOR);
        
        lbl.setFont( font.deriveFont(size) );
        lbl_.setFont( font.deriveFont(size) );
        lbl.setBackground(UIConstants.TABLE_COLOR);
        lbl_.setBackground(UIConstants.TABLE_COLOR);
        
        this.p = pokerInterface;
        
        this.setBackground(UIConstants.TABLE_COLOR);
    
        this.setLayout(new GridLayout(2,7));
    
        this.add(lbl);

        this.add(pot);

        this.add(lbl_);

        this.add(bet);
              
    }
    
    
}
