/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package holdem;

import java.awt.image.BufferedImage;

import java.awt.Robot;
import java.awt.Rectangle;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;

public class Match {
    
    static String getCard(int tableType, int playerPosition, int phase){
    
        BufferedImage img = null;
        //BufferedImage template = null;
        try {
            
            Rectangle rectPreFlop1 = null;
            Rectangle rectPreFlop2 = null;
            Rectangle rectFlop1 = null;
            Rectangle rectFlop2 = null;
            Rectangle rectFlop3 = null;
            Rectangle rectTurn = null;
            Rectangle rectRiver = null;
            
            
            int A, B, C, D, E, F, G, H, I, J, 
                    K, L, M, N, O, P, Q, 
                    R, S, T, U, V, Y, 
                    AB, CD, EF, GH, IJ, KL,
                    MN, OP, QR, ST, UV, YZ= 0;
            
            //player1
            A = 1006;
            B = 1060;
            C = 77;
                                               
            //player2
            L = 1176;
            M = 1230;
            N = 138;
            
            //player3
            O = 1223;
            P = 1277;
            Q = 261;
                       
            //player4
            R = 1124;
            S = 1179;
            T = 387;
            
            //player5
            U = 878; 
            V = 932;
            Y = 432;
                        
            //player6
            AB = 631;
            CD = 682; 
            EF = 368;
            
            //player7
            GH = 533;
            IJ = 586;
            KL = 261;
            
            //player8           
            MN = 579;
            OP = 634;
            QR = 137;
            
            //player9
            ST = 749;
            UV = 803;
            YZ = 77;
            
                        
            //Flop
            D = 259;
            E = 798;
            F = 852; 
            G = 906;
            H = 960;
            I = 1015;
            
            
            //card dimension
            J = 32;
            K = 44;
            
            
            if(tableType == 9){
                if(playerPosition == 1){               
                    rectPreFlop1 = new Rectangle(A, C, J, K);
                    rectPreFlop2 = new Rectangle(B, C, J, K);                
                }
                if(playerPosition == 2){
                    rectPreFlop1 = new Rectangle(L, N, J, K);
                    rectPreFlop2 = new Rectangle(M, N, J, K);
                
                }
                if(playerPosition == 3){
                    rectPreFlop1 = new Rectangle(O, Q, J, K);
                    rectPreFlop2 = new Rectangle(P, Q, J, K);
                }
                if(playerPosition == 4){
                    rectPreFlop1 = new Rectangle(R, T, J, K);
                    rectPreFlop2 = new Rectangle(S, T, J, K);  
                }
                if(playerPosition == 5){
                    rectPreFlop1 = new Rectangle(U, Y, J, K);
                    rectPreFlop2 = new Rectangle(V, Y, J, K); 
                }
                if(playerPosition == 6){
                    rectPreFlop1 = new Rectangle(AB, EF, J, K);
                    rectPreFlop2 = new Rectangle(CD, EF, J, K); 
                }
                if(playerPosition == 7){
                    rectPreFlop1 = new Rectangle(GH, KL, J, K);
                    rectPreFlop2 = new Rectangle(IJ, KL, J, K); 
                }
                if(playerPosition == 8){
                    rectPreFlop1 = new Rectangle(MN, QR, J, K);
                    rectPreFlop2 = new Rectangle(OP, QR, J, K);
                }
                if(playerPosition == 9){
                    rectPreFlop1 = new Rectangle(ST, YZ, J, K);
                    rectPreFlop2 = new Rectangle(UV, YZ, J, K);
                }
            }
            if(tableType == 6){
                if(playerPosition == 1){                
                    rectPreFlop1 = new Rectangle(1087,60, 30, 40);
                    rectPreFlop2 = new Rectangle(1126,60, 30, 40); 
                }
                if(playerPosition == 2){
                    rectPreFlop1 = new Rectangle(1087,60, 30, 40);
                    rectPreFlop2 = new Rectangle(1126,60, 30, 40); 
                }
                if(playerPosition == 3){
                    rectPreFlop1 = new Rectangle(1087,60, 30, 40);
                    rectPreFlop2 = new Rectangle(1126,60, 30, 40); 
                }
                if(playerPosition == 4){
                    rectPreFlop1 = new Rectangle(1226,595, 24, 70);
                    rectPreFlop2 = new Rectangle(1252,595, 24, 70);                
                }
                if(playerPosition == 5){
                    rectPreFlop1 = new Rectangle(1087,60, 30, 40);
                    rectPreFlop2 = new Rectangle(1126,60, 30, 40);                              
                }
                if(playerPosition == 6){
                    rectPreFlop1 = new Rectangle(1087,60, 30, 40);
                    rectPreFlop2 = new Rectangle(1126,60, 30, 40);                
                }
            }
            if(tableType == 4){
                if(playerPosition == 1){
                    rectPreFlop1 = new Rectangle(1087,60, 30, 40);
                    rectPreFlop2 = new Rectangle(1126,60, 30, 40);                               
                }
                if(playerPosition == 2){
                    rectPreFlop1 = new Rectangle(1087,60, 30, 40);
                    rectPreFlop2 = new Rectangle(1126,60, 30, 40);                 
                }
                if(playerPosition == 3){
                    rectPreFlop1 = new Rectangle(1087,60, 30, 40);
                    rectPreFlop2 = new Rectangle(1126,60, 30, 40);                
                }
                if(playerPosition == 4){
                    rectPreFlop1 = new Rectangle(1087,60, 30, 40);
                    rectPreFlop2 = new Rectangle(1126,60, 30, 40);                  
                }
            }
            if(tableType == 2){
                if(playerPosition == 1){
                    rectPreFlop1 = new Rectangle(1087,60, 30, 40);
                    rectPreFlop2 = new Rectangle(1126,60, 30, 40);                
                }
                if(playerPosition == 2){
                    rectPreFlop1 = new Rectangle(1087,60, 30, 40);
                    rectPreFlop2 = new Rectangle(1126,60, 30, 40);                
                }
            }
            
            
            rectFlop1 =  new Rectangle(E, D, J, K);
            
            rectFlop2 =  new Rectangle(F, D, J, K);
            
            rectFlop3 =  new Rectangle(G, D, J, K);

            rectTurn =  new Rectangle(H, D, J, K);
            
            rectRiver =  new Rectangle(I, D, J, K);

            if(phase==1){
                img = new Robot().createScreenCapture(rectPreFlop1);          
            }            
            if(phase==2){
                img = new Robot().createScreenCapture(rectPreFlop2);            
            }                        
            if(phase==3){
                img = new Robot().createScreenCapture(rectFlop1);
            } 
            if(phase==4){
                img = new Robot().createScreenCapture(rectFlop2);
            } 
            if(phase==5){
                img = new Robot().createScreenCapture(rectFlop3);
            }                        
            if(phase==6){
                img = new Robot().createScreenCapture(rectTurn);
            }               
            if(phase==7){
                img = new Robot().createScreenCapture(rectRiver);            
            }


            
            //File fileEntry = new File("C:\\Users\\ValentinBura\\Desktop\\pic");            
            //ImageIO.write(img, "png", fileEntry);
            
            //System.out.println(img);
            
            
            
        } catch (Exception e) {
                    System.out.println(e);
        }
        

 String n = getNumeric(img);       
 String s = getSuit(img);       
        


    String card = "";
    card += s;
    card += n;

    card += ".png";
    
    System.out.println(card);
    return card;    
}
 
static String getNumeric(BufferedImage img){

String cardNumber = "2";
    
ArrayList<String> cardTemplates = new ArrayList();
File dir = new File("C:\\Users\\ValentinBura\\Desktop\\NetBeansProjects\\HoldemAI\\images_\\numeric");
  File[] directoryListing = dir.listFiles();
  if (directoryListing != null) {
    for (File child : directoryListing) {
      cardTemplates.add(child.getName());
      //System.out.println(child.getName());
    }
  } else {
    System.out.println("template error");
 }



for(String cardName : cardTemplates){
        //System.out.println(cardName);
        BufferedImage template = null;
        try {
            template = ImageIO.read(new File("C:\\Users\\ValentinBura\\Desktop\\NetBeansProjects\\HoldemAI\\images_\\numeric\\"+cardName));
            
        } catch (IOException e) {
            System.out.println("template error");
        }  
  
  

//double minSAD = 1000;        
for ( int x = 0; x < img.getWidth()-template.getWidth(); x++ ) {
    for ( int y = 0; y < img.getHeight()-template.getHeight(); y++ ) {
        
        double SAD = 0.0;
        
        for ( int j = 0; j < template.getWidth(); j++ ){
            for ( int i = 0; i < template.getHeight(); i++ ) {

                
                
                int rgbIm = img.getRGB(x+j, y+i);                                
                int rgbTm = template.getRGB(j, i);
                   
                if (rgbIm == rgbTm){
                    SAD++;
                }
                
                //SAD += Math.abs(rgbIm - rgbTm);
   
                //SAD += Math.abs(rgbIm - rgbTm);                                
            }           
        }

        if ((SAD == template.getWidth() * template.getHeight()))             
        {    
            //minSAD = SAD;
            cardNumber = cardName.substring(0,1);
            //System.out.println(cardNumber);
            return cardNumber;
        }        
    }    
} 
}                    
    return cardNumber;
}

static String getSuit(BufferedImage img){
 
String cardSuit = "d";    
    

ArrayList<String> cardTemplates_ = new ArrayList();
File dir_ = new File("C:\\Users\\ValentinBura\\Desktop\\NetBeansProjects\\HoldemAI\\images_\\suit");
  File[] directoryListing_ = dir_.listFiles();
  if (directoryListing_ != null) {
    for (File child_ : directoryListing_) {
      cardTemplates_.add(child_.getName());
      //System.out.println(child_.getName());
    }
  } else {
    System.out.println("template error");
 }



for(String cardName : cardTemplates_){
        //System.out.println(cardName);
        BufferedImage template = null;
        try {
            template = ImageIO.read(new File("C:\\Users\\ValentinBura\\Desktop\\NetBeansProjects\\HoldemAI\\images_\\suit\\"+cardName));
            
        } catch (IOException e) {
            System.out.println("template error");
        }  
  

double minSAD = Double.MIN_VALUE;
for ( int x = 0; x < img.getWidth()-template.getWidth(); x++ ) {
    for ( int y = 0; y < img.getHeight()-template.getHeight(); y++ ) {
        
        double SAD = 0.0;

        for ( int j = 0; j < template.getWidth(); j++ ){
            for ( int i = 0; i < template.getHeight(); i++ ) {

                int rgbIm = img.getRGB(x+j, y+i);
                                
                int rgbTm = template.getRGB(j, i);
                              
                if(rgbIm == rgbTm){
                    SAD++;
                }
                //SAD += Math.abs(rgbIm - rgbTm); 
                               
            }           
        }

        
        if ((SAD == template.getWidth() * template.getHeight()))             
        {      
            //minSAD = SAD;
            cardSuit = cardName.substring(0,1);
            return cardSuit;
        }        
    }    
}
}      
    return cardSuit;
}    
    
}

